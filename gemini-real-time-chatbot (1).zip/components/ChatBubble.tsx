import React from 'react';
import { Role } from '../types';
import { Icon } from './Icon';

interface ChatBubbleProps {
  role: Role;
  text: string;
  isPartial?: boolean;
  isLoading?: boolean;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({ role, text, isPartial = false, isLoading = false }) => {
  const isUser = role === Role.USER;

  const bubbleClasses = isUser
    ? 'bg-blue-600 self-end rounded-tl-2xl rounded-tr-2xl rounded-bl-2xl'
    : 'bg-slate-700 self-start rounded-tr-2xl rounded-tl-2xl rounded-br-2xl';
  
  const opacityClass = isPartial ? 'opacity-70' : 'opacity-100';

  return (
    <div className={`flex items-start gap-3 w-full max-w-2xl mx-auto ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
      <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${isUser ? 'bg-blue-800' : 'bg-slate-800'}`}>
        <Icon name={isUser ? 'user' : 'gemini'} />
      </div>
      <div className={`p-4 text-white shadow-md animate-fade-in-up ${bubbleClasses} ${opacityClass}`}>
        {isLoading ? (
          <div className="flex items-center space-x-1">
            <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse-fast"></span>
            <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse-fast delay-150"></span>
            <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse-fast delay-300"></span>
          </div>
        ) : (
          <p className="whitespace-pre-wrap">{text}</p>
        )}
      </div>
    </div>
  );
};