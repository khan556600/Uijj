
import React from 'react';

interface IconProps {
  name: 'microphone' | 'stop' | 'spinner' | 'gemini' | 'user';
  size?: string;
  className?: string;
}

export const Icon: React.FC<IconProps> = ({ name, size = 'w-6 h-6', className = '' }) => {
  // FIX: Replaced JSX.Element with React.ReactElement to resolve "Cannot find namespace 'JSX'" error.
  const icons: { [key: string]: React.ReactElement } = {
    microphone: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 0 0 6-6v-1.5m-6 7.5a6 6 0 0 1-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 0 1-3-3V4.5a3 3 0 0 1 6 0v8.25a3 3 0 0 1-3 3Z" />
      </svg>
    ),
    stop: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 7.5A2.25 2.25 0 0 1 7.5 5.25h9a2.25 2.25 0 0 1 2.25 2.25v9a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-9Z" />
      </svg>
    ),
    spinner: (
      <svg className="animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
      </svg>
    ),
    gemini: (
        <svg fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 12a3.5 3.5 0 0 1-3.5-3.5H6a6 6 0 0 0 6 6Z"></path>
            <path d="M12 12a3.5 3.5 0 0 1 3.5 3.5h2.5a6 6 0 0 0-6-6Z"></path>
            <path d="M12 12a3.5 3.5 0 0 0 3.5-3.5h-2.5a1 1 0 0 1-1 1Z"></path>
            <path d="M12 12a3.5 3.5 0 0 0-3.5 3.5h2.5a1 1 0 0 1 1-1Z"></path>
            <path fillRule="evenodd" d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12ZM3.515 8.5A8.5 8.5 0 0 1 12 3.5v2.015a6.015 6.015 0 0 0-6.015 6.015H3.515Zm16.97 7A8.5 8.5 0 0 1 12 20.5v-2.015a6.015 6.015 0 0 0 6.015-6.015h2.47Z" clipRule="evenodd"></path>
        </svg>
    ),
    user: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
      </svg>
    ),
  };

  return <div className={`${size} ${className}`}>{icons[name]}</div>;
};