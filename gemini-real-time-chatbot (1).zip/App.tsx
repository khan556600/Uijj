import React, { useRef, useEffect, useState } from 'react';
import { useGeminiChat } from './hooks/useGeminiChat';
import { ChatBubble } from './components/ChatBubble';
import { ConnectionState, Message, Role } from './types';
import { Icon } from './components/Icon';

const App: React.FC = () => {
  const {
    connectionState,
    chatHistory,
    currentUserTurn,
    currentModelTurn,
    startSession,
    endSession,
    error,
  } = useGeminiChat();

  const [isModelThinking, setIsModelThinking] = useState(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory, currentUserTurn, currentModelTurn, isModelThinking]);

  useEffect(() => {
    const lastMessage = chatHistory.length > 0 ? chatHistory[chatHistory.length - 1] : null;

    // Show thinking indicator if the last message was from the user and the model isn't responding yet.
    if (lastMessage && lastMessage.role === Role.USER && !currentModelTurn) {
        setIsModelThinking(true);
    } else {
        setIsModelThinking(false);
    }
  }, [chatHistory, currentModelTurn]);

  const renderActionButton = () => {
    switch (connectionState) {
      case ConnectionState.DISCONNECTED:
        return (
          <button
            onClick={startSession}
            className="bg-blue-600 hover:bg-blue-700 text-white rounded-full p-4 transition-all duration-300 ease-in-out shadow-lg transform hover:scale-105 flex items-center justify-center space-x-2"
          >
            <Icon name="microphone" />
            <span>Start Session</span>
          </button>
        );
      case ConnectionState.CONNECTING:
        return (
          <button
            disabled
            className="bg-gray-500 text-white rounded-full p-4 transition-all duration-300 ease-in-out shadow-lg flex items-center justify-center space-x-2 cursor-not-allowed"
          >
            <Icon name="spinner" />
            <span>Connecting...</span>
          </button>
        );
      case ConnectionState.CONNECTED:
        return (
          <button
            onClick={endSession}
            className="bg-red-600 hover:bg-red-700 text-white rounded-full p-4 transition-all duration-300 ease-in-out shadow-lg transform hover:scale-105 flex items-center justify-center space-x-2"
          >
            <Icon name="stop" />
            <span>End Session</span>
          </button>
        );
    }
  };
  
  const getStatusIndicator = () => {
    switch (connectionState) {
        case ConnectionState.DISCONNECTED:
            return <div className="flex items-center space-x-2"><div className="w-3 h-3 bg-gray-400 rounded-full"></div><span>Idle</span></div>;
        case ConnectionState.CONNECTING:
            return <div className="flex items-center space-x-2"><div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div><span>Connecting</span></div>;
        case ConnectionState.CONNECTED:
            return <div className="flex items-center space-x-2"><div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div><span>Connected</span></div>;
    }
  }

  return (
    <div className="flex flex-col h-screen bg-slate-900 text-white font-sans">
      <header className="flex items-center justify-between p-4 border-b border-slate-700 shadow-md">
        <div className="flex items-center space-x-3">
          <Icon name="gemini" />
          <h1 className="text-2xl font-bold text-slate-100">Real-Time AI Chat</h1>
        </div>
        <div className="text-sm text-slate-300">
            {getStatusIndicator()}
        </div>
      </header>

      <main ref={chatContainerRef} className="flex-1 overflow-y-auto p-6 space-y-6">
        {chatHistory.map((msg, index) => (
          <ChatBubble key={index} role={msg.role} text={msg.text} />
        ))}
        {currentUserTurn && <ChatBubble role="user" text={currentUserTurn} isPartial />}
        {isModelThinking && <ChatBubble role="model" text="" isLoading={true} />}
        {currentModelTurn && <ChatBubble role="model" text={currentModelTurn} isPartial />}
        {chatHistory.length === 0 && !currentUserTurn && !currentModelTurn && (
          <div className="flex flex-col items-center justify-center h-full text-slate-500">
             <Icon name="gemini" size="h-16 w-16" />
             <p className="mt-4 text-lg">Start a conversation by clicking the button below.</p>
          </div>
        )}
      </main>

      <footer className="p-4 flex flex-col items-center justify-center border-t border-slate-700">
        {error && <p className="text-red-400 mb-2">{error}</p>}
        {renderActionButton()}
      </footer>
    </div>
  );
};

export default App;